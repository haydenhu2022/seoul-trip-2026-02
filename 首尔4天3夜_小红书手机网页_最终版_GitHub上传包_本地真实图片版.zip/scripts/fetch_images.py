import os, re, time
from pathlib import Path
from urllib.parse import urljoin
import requests
from PIL import Image
from io import BytesIO

SOURCES = [
    ("0918-samgyetang", "3대 삼계장인", "https://polle.com/place/2PWMxQ/3%EB%8C%80%20%EC%82%BC%EA%B3%84%EC%9E%A5%EC%9D%B8"),
    ("0918-sansol", "산솔 신논현점", "https://www.socialdancelive.com/landing/sansol-sinnonhyeonjeom"),
    ("0919-grino", "그리노 성수", "https://www.diningcode.com/profile.php?rid=OyzeCQISJYoM"),
    ("0919-mils", "밀스 성수", "https://www.tabling.co.kr/place/677cd5fe66de5f0698903464"),
    ("0919-dob", "돕감자탕전문점", "https://www.daangn.com/kr/local-profile/%EB%8F%95%EA%B0%90%EC%9E%90%ED%83%95%EC%A0%84%EB%AC%B8%EC%A0%90-hc6nnzhjepfq/"),
    ("0920-eggdrop", "EGGDROP 강남본점", "https://www.eggdrop.com/store/map.php"),
    ("0920-eel", "황소 유황오리·풍천민물장어", "https://www.diningcode.com/profile.php?rid=KdEIxzlOTDHA"),
    ("0920-jangin", "장인닭갈비 명동점", "https://www.tabling.co.kr/place/677cd44a66de5f06988d237d"),
    ("0920-on65", "온6.5", "https://polle.com/place/4BoyGh/%EC%98%A8%206.5"),
]

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; SeoulTripStaticSite/1.0)"}
OUT = Path("images")
OUT.mkdir(exist_ok=True)

def get_og_image(page_url):
    r = requests.get(page_url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    html = r.text
    patterns = [
        r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']',
        r'<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)["\']',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']twitter:image["\']',
    ]
    for p in patterns:
        m = re.search(p, html, re.I)
        if m:
            return urljoin(page_url, m.group(1))
    # fallback: first reasonably large-looking image URL
    for m in re.finditer(r'<img[^>]+src=["\']([^"\']+)["\']', html, re.I):
        u = urljoin(page_url, m.group(1))
        if not u.startswith("data:"):
            return u
    raise RuntimeError("No image found")

for slug, name, page in SOURCES:
    target = OUT / f"{slug}.jpg"
    try:
        img_url = get_og_image(page)
        print(f"{name}: {img_url}")
        r = requests.get(img_url, headers={**HEADERS, "Referer": page}, timeout=30)
        r.raise_for_status()
        im = Image.open(BytesIO(r.content)).convert("RGB")
        im.thumbnail((1600,1600))
        im.save(target, "JPEG", quality=90, optimize=True)
        print(f"  saved {target}")
    except Exception as e:
        print(f"FAILED {name}: {e}")
        # Create no fake image. The workflow will report failure clearly.
        if target.exists():
            target.unlink()
        raise
    time.sleep(0.5)
