# 首尔4天3夜 · GitHub Pages 最终上传包

## 上传
把本文件夹内的全部内容上传到 GitHub 仓库根目录，确保 `index.html` 位于根目录。

## 图片
9 家餐厅的图片不会再从 HTML 外链读取。
GitHub Actions 会根据对应门店页面抓取 `og:image`，转换成 JPG 后保存到 `images/`，网页只读取本地 `images/*.jpg`。

## 注意
第一次上传后进入 GitHub → Actions → Prepare local restaurant photos。
成功运行后，`images/` 会自动出现 9 张 JPG，并再次推送到仓库。
